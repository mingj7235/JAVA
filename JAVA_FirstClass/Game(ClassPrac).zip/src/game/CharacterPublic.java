package game;

public abstract class CharacterPublic {
	

	
	
	abstract String attack (int cDamage, int mHp);
	abstract void defense ();
	abstract void escape ();
	
	
	abstract void showStatus ();
	
	
	
	
	
	
}
