public class Main {
    public static void main(String[] args) {
        Business bc = new Business();
        bc.start();
    }//end main
}//end class