public interface Interface {
    public abstract int ticketPrice(String seat);
}//end inter